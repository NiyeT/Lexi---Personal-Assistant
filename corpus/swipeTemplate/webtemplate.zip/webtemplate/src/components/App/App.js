class App extends React.Component {
  render() {
    return React.createElement('div', null, `App ${this.props.toWhat}`);
  }
}

exports.App=App;
