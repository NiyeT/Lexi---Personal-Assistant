import Beacon from "../../libraries/beacon/index.js";

window.Beacon=new Beacon();
window.requests=axios;
window.Component=React.Component;
window.c=React.createElement;
window.r=ReactDOM.render;
