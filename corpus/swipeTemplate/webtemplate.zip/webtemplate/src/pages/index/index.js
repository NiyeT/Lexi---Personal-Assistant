import SplashScreen from "../splash-screen/splash-screen.js";

r(c(SplashScreen),document.querySelector("#root"));
