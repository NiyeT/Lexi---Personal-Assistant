import SplashScreen from "../../components/splash-screen/splash-screen.js";

export default SplashScreen
