import React from "react"

const Orders = () => (
  <>
    <h1>Your orders</h1>
    TODO: pull orders and display them
  </>
)

export default Orders
