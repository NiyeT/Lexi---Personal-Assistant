# Sections

## Sections
In the data model, Sections is an array. The Sections.js file takes loops over the array of sections to build out the page.

Sections stack on top of each other and span the full width of the viewing window.