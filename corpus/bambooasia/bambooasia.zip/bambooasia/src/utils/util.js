import { addMinutes } from "date-fns"

export const startingDate = () => addMinutes( new Date(), 30);
