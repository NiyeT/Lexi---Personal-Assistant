import "./src/styles/font-awesome.css"

import wrapWithProvider from './wrap-with-provider'
export const wrapRootElement = wrapWithProvider
