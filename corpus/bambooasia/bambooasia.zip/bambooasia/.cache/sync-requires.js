const { hot } = require("react-hot-loader/root")

// prefer default export if available
const preferDefault = m => m && m.default || m


exports.components = {
  "component---src-templates-default-js": hot(preferDefault(require("/home/guardin/Documents/bambooasia/src/templates/Default.js"))),
  "component---cache-dev-404-page-js": hot(preferDefault(require("/home/guardin/Documents/bambooasia/.cache/dev-404-page.js"))),
  "component---src-pages-404-js": hot(preferDefault(require("/home/guardin/Documents/bambooasia/src/pages/404.js"))),
  "component---src-pages-account-js": hot(preferDefault(require("/home/guardin/Documents/bambooasia/src/pages/account.js"))),
  "component---src-pages-callback-js": hot(preferDefault(require("/home/guardin/Documents/bambooasia/src/pages/callback.js"))),
  "component---src-pages-index-js": hot(preferDefault(require("/home/guardin/Documents/bambooasia/src/pages/index.js")))
}

