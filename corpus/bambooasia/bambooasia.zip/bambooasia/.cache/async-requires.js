// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---src-templates-default-js": () => import("/home/guardin/Documents/bambooasia/src/templates/Default.js" /* webpackChunkName: "component---src-templates-default-js" */),
  "component---cache-dev-404-page-js": () => import("/home/guardin/Documents/bambooasia/.cache/dev-404-page.js" /* webpackChunkName: "component---cache-dev-404-page-js" */),
  "component---src-pages-404-js": () => import("/home/guardin/Documents/bambooasia/src/pages/404.js" /* webpackChunkName: "component---src-pages-404-js" */),
  "component---src-pages-account-js": () => import("/home/guardin/Documents/bambooasia/src/pages/account.js" /* webpackChunkName: "component---src-pages-account-js" */),
  "component---src-pages-callback-js": () => import("/home/guardin/Documents/bambooasia/src/pages/callback.js" /* webpackChunkName: "component---src-pages-callback-js" */),
  "component---src-pages-index-js": () => import("/home/guardin/Documents/bambooasia/src/pages/index.js" /* webpackChunkName: "component---src-pages-index-js" */)
}

exports.data = () => import(/* webpackChunkName: "pages-manifest" */ "/home/guardin/Documents/bambooasia/.cache/data.json")

