module.exports = [{
      plugin: require('/home/guardin/Documents/bambooasia/node_modules/gatsby-plugin-canonical-urls/gatsby-browser.js'),
      options: {"plugins":[],"siteUrl":"https://www.bambooasia.com"},
    },{
      plugin: require('/home/guardin/Documents/bambooasia/node_modules/gatsby-remark-autolink-headers/gatsby-browser.js'),
      options: {"plugins":[]},
    },{
      plugin: require('/home/guardin/Documents/bambooasia/node_modules/gatsby-plugin-catch-links/gatsby-browser.js'),
      options: {"plugins":[]},
    },{
      plugin: require('/home/guardin/Documents/bambooasia/node_modules/gatsby-plugin-google-analytics/gatsby-browser.js'),
      options: {"plugins":[],"head":true},
    },{
      plugin: require('/home/guardin/Documents/bambooasia/node_modules/gatsby-plugin-offline/gatsby-browser.js'),
      options: {"plugins":[]},
    },{
      plugin: require('/home/guardin/Documents/bambooasia/node_modules/gatsby-plugin-nprogress/gatsby-browser.js'),
      options: {"plugins":[],"color":"#121212"},
    },{
      plugin: require('/home/guardin/Documents/bambooasia/gatsby-browser.js'),
      options: {"plugins":[]},
    }]
